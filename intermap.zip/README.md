# InterMap

## 1) Get The Repository
git clone git@github.com:balzac2806/intermap.git

## 2) Build
- Start in console:
gulp

## 3) Bower 
- DIR intermap/public/
bower install
