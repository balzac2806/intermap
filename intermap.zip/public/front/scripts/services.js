interMap.service('interMapAPI', [], function () {

});


//# sourceMappingURL=services.js.map
