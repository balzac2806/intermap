interMap.service('interMapAPI', [], function () {

});

