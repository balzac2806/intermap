interMap.controller('dashboardController', ['$scope', function ($scope) {
        console.log('dashboardController');
    }]);
interMap.controller('testController', ['$scope', function ($scope) {
        console.log('testController');
    }]);
